"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Trash2, Eye, Plus, Monitor } from "lucide-react"
import Link from "next/link"

interface Patient {
  id: string
  name: string
  ticketNumber: number
  type: "medico" | "odontologico"
  status: "aguardando" | "chamando" | "atendimento"
  timestamp: number
}

export default function AdminPanel() {
  const [patients, setPatients] = useState<Patient[]>([])
  const [patientName, setPatientName] = useState("")
  const [serviceType, setServiceType] = useState<"medico" | "odontologico">("medico")
  const [nextTicketNumber, setNextTicketNumber] = useState(1)

  // Carregar dados do localStorage
  useEffect(() => {
    const savedPatients = localStorage.getItem("medical-queue-patients")
    const savedTicketNumber = localStorage.getItem("medical-queue-next-ticket")

    if (savedPatients) {
      setPatients(JSON.parse(savedPatients))
    }
    if (savedTicketNumber) {
      setNextTicketNumber(Number.parseInt(savedTicketNumber))
    }
  }, [])

  // Salvar dados no localStorage
  useEffect(() => {
    localStorage.setItem("medical-queue-patients", JSON.stringify(patients))
    localStorage.setItem("medical-queue-next-ticket", nextTicketNumber.toString())
  }, [patients, nextTicketNumber])

  const addPatient = () => {
    if (!patientName.trim()) return

    const newPatient: Patient = {
      id: Date.now().toString(),
      name: patientName.trim(),
      ticketNumber: nextTicketNumber,
      type: serviceType,
      status: "aguardando",
      timestamp: Date.now(),
    }

    setPatients((prev) => [...prev, newPatient])
    setNextTicketNumber((prev) => prev + 1)
    setPatientName("")
  }

  const removePatient = (id: string) => {
    setPatients((prev) => prev.filter((p) => p.id !== id))
  }

  const updatePatientStatus = (id: string, status: Patient["status"]) => {
    setPatients((prev) => prev.map((p) => (p.id === id ? { ...p, status } : p)))
  }

  const getStatusColor = (status: Patient["status"]) => {
    switch (status) {
      case "aguardando":
        return "bg-yellow-500"
      case "chamando":
        return "bg-blue-500"
      case "atendimento":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusText = (status: Patient["status"]) => {
    switch (status) {
      case "aguardando":
        return "Aguardando"
      case "chamando":
        return "Chamando"
      case "atendimento":
        return "Em Atendimento"
      default:
        return "Desconhecido"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Sistema de Atendimento Médico</h1>
            <p className="text-gray-600">Painel Administrativo</p>
          </div>
          <Link href="/display">
            <Button className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              Painel Público
            </Button>
          </Link>
        </div>

        {/* Formulário para adicionar paciente */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Adicionar Novo Paciente
            </CardTitle>
            <CardDescription>Preencha os dados do paciente para gerar uma nova ficha</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="patient-name">Nome do Paciente</Label>
                <Input
                  id="patient-name"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="Digite o nome completo"
                  onKeyPress={(e) => e.key === "Enter" && addPatient()}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="service-type">Tipo de Atendimento</Label>
                <Select value={serviceType} onValueChange={(value: "medico" | "odontologico") => setServiceType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="medico">Consultório Médico</SelectItem>
                    <SelectItem value="odontologico">Consultório Odontológico</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button onClick={addPatient} className="w-full">
                  Gerar Ficha #{nextTicketNumber}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de pacientes */}
        <Card>
          <CardHeader>
            <CardTitle>Fila de Atendimento ({patients.length} pacientes)</CardTitle>
            <CardDescription>Gerencie o status dos pacientes na fila</CardDescription>
          </CardHeader>
          <CardContent>
            {patients.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Eye className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Nenhum paciente na fila</p>
              </div>
            ) : (
              <div className="space-y-3">
                {patients.map((patient) => (
                  <div key={patient.id} className="flex items-center justify-between p-4 border rounded-lg bg-white">
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">#{patient.ticketNumber}</div>
                        <div className="text-xs text-gray-500">{patient.type === "medico" ? "Médico" : "Odonto"}</div>
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg">{patient.name}</h3>
                        <p className="text-sm text-gray-600">
                          {new Date(patient.timestamp).toLocaleTimeString("pt-BR")}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Badge className={`${getStatusColor(patient.status)} text-white`}>
                        {getStatusText(patient.status)}
                      </Badge>

                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant={patient.status === "aguardando" ? "default" : "outline"}
                          onClick={() => updatePatientStatus(patient.id, "aguardando")}
                        >
                          Aguardando
                        </Button>
                        <Button
                          size="sm"
                          variant={patient.status === "chamando" ? "default" : "outline"}
                          onClick={() => updatePatientStatus(patient.id, "chamando")}
                        >
                          Chamar
                        </Button>
                        <Button
                          size="sm"
                          variant={patient.status === "atendimento" ? "default" : "outline"}
                          onClick={() => updatePatientStatus(patient.id, "atendimento")}
                        >
                          Atender
                        </Button>
                      </div>

                      <Button size="sm" variant="destructive" onClick={() => removePatient(patient.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">
                {patients.filter((p) => p.status === "aguardando").length}
              </div>
              <div className="text-sm text-gray-600">Aguardando</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {patients.filter((p) => p.status === "chamando").length}
              </div>
              <div className="text-sm text-gray-600">Chamando</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">
                {patients.filter((p) => p.status === "atendimento").length}
              </div>
              <div className="text-sm text-gray-600">Em Atendimento</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-gray-600">{patients.length}</div>
              <div className="text-sm text-gray-600">Total</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
