"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, Users, Stethoscope, SmileIcon as Tooth } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

interface Patient {
  id: string
  name: string
  ticketNumber: number
  type: "medico" | "odontologico"
  status: "aguardando" | "chamando" | "atendimento"
  timestamp: number
}

export default function DisplayPanel() {
  const [patients, setPatients] = useState<Patient[]>([])
  const [currentTime, setCurrentTime] = useState(new Date())

  // Atualizar dados a cada 2 segundos
  useEffect(() => {
    const loadPatients = () => {
      const savedPatients = localStorage.getItem("medical-queue-patients")
      if (savedPatients) {
        setPatients(JSON.parse(savedPatients))
      }
    }

    loadPatients()
    const interval = setInterval(loadPatients, 2000)
    return () => clearInterval(interval)
  }, [])

  // Atualizar relógio
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const getStatusColor = (status: Patient["status"]) => {
    switch (status) {
      case "aguardando":
        return "bg-yellow-500"
      case "chamando":
        return "bg-blue-500 animate-pulse"
      case "atendimento":
        return "bg-green-500"
      default:
        return "bg-gray-500"
    }
  }

  const getStatusText = (status: Patient["status"]) => {
    switch (status) {
      case "aguardando":
        return "Aguardando"
      case "chamando":
        return "CHAMANDO"
      case "atendimento":
        return "Em Atendimento"
      default:
        return "Desconhecido"
    }
  }

  const waitingPatients = patients.filter((p) => p.status === "aguardando")
  const callingPatients = patients.filter((p) => p.status === "chamando")
  const inServicePatients = patients.filter((p) => p.status === "atendimento")

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-gray-900">Painel de Atendimento</h1>
          <div className="flex items-center justify-center gap-4 text-lg text-gray-600">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              {currentTime.toLocaleTimeString("pt-BR")}
            </div>
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              {patients.length} pacientes
            </div>
          </div>
          <Link href="/">
            <Button variant="outline" size="sm">
              Voltar ao Painel Admin
            </Button>
          </Link>
        </div>

        {/* Pacientes sendo chamados */}
        {callingPatients.length > 0 && (
          <Card className="border-blue-500 border-2 bg-blue-50">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold text-blue-700 mb-4 text-center">🔊 CHAMANDO PARA ATENDIMENTO</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {callingPatients.map((patient) => (
                  <div
                    key={patient.id}
                    className="bg-white p-6 rounded-lg border-2 border-blue-500 text-center animate-pulse"
                  >
                    <div className="text-4xl font-bold text-blue-600 mb-2">#{patient.ticketNumber}</div>
                    <div className="text-xl font-semibold text-gray-900 mb-2">{patient.name}</div>
                    <div className="flex items-center justify-center gap-2 text-blue-600">
                      {patient.type === "medico" ? (
                        <>
                          <Stethoscope className="h-5 w-5" />
                          <span>Consultório Médico</span>
                        </>
                      ) : (
                        <>
                          <Tooth className="h-5 w-5" />
                          <span>Consultório Odontológico</span>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Pacientes em atendimento */}
        {inServicePatients.length > 0 && (
          <Card className="border-green-500 border-2 bg-green-50">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold text-green-700 mb-4 text-center">⚕️ EM ATENDIMENTO</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {inServicePatients.map((patient) => (
                  <div key={patient.id} className="bg-white p-4 rounded-lg border border-green-300 text-center">
                    <div className="text-2xl font-bold text-green-600 mb-1">#{patient.ticketNumber}</div>
                    <div className="text-lg font-semibold text-gray-900 mb-1">{patient.name}</div>
                    <div className="flex items-center justify-center gap-1 text-green-600 text-sm">
                      {patient.type === "medico" ? (
                        <>
                          <Stethoscope className="h-4 w-4" />
                          <span>Médico</span>
                        </>
                      ) : (
                        <>
                          <Tooth className="h-4 w-4" />
                          <span>Odonto</span>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Fila de espera */}
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold text-gray-700 mb-4 text-center">⏳ FILA DE ESPERA</h2>
            {waitingPatients.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Users className="h-16 w-16 mx-auto mb-4 opacity-50" />
                <p className="text-xl">Nenhum paciente aguardando</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                {waitingPatients.map((patient) => (
                  <div key={patient.id} className="bg-gray-50 p-4 rounded-lg text-center border">
                    <div className="text-2xl font-bold text-gray-700 mb-1">#{patient.ticketNumber}</div>
                    <div className="text-sm font-medium text-gray-900 mb-1 truncate" title={patient.name}>
                      {patient.name}
                    </div>
                    <div className="flex items-center justify-center gap-1 text-gray-600 text-xs">
                      {patient.type === "medico" ? (
                        <>
                          <Stethoscope className="h-3 w-3" />
                          <span>Médico</span>
                        </>
                      ) : (
                        <>
                          <Tooth className="h-3 w-3" />
                          <span>Odonto</span>
                        </>
                      )}
                    </div>
                    <Badge variant="secondary" className="mt-2 text-xs">
                      {getStatusText(patient.status)}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Estatísticas */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-yellow-50 border-yellow-200">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-yellow-600">{waitingPatients.length}</div>
              <div className="text-sm text-yellow-700">Aguardando</div>
            </CardContent>
          </Card>
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-blue-600">{callingPatients.length}</div>
              <div className="text-sm text-blue-700">Chamando</div>
            </CardContent>
          </Card>
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-green-600">{inServicePatients.length}</div>
              <div className="text-sm text-green-700">Em Atendimento</div>
            </CardContent>
          </Card>
          <Card className="bg-gray-50 border-gray-200">
            <CardContent className="p-4 text-center">
              <div className="text-3xl font-bold text-gray-600">{patients.length}</div>
              <div className="text-sm text-gray-700">Total</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
